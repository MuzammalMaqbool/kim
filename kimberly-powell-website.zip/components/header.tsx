"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
} from "@/components/ui/navigation-menu"
import { Menu, Heart, Phone, Mail, ChevronDown } from "lucide-react"

export default function Header() {
  const [isOpen, setIsOpen] = useState(false)
  const [isScrolled, setIsScrolled] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10)
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const navigation = [
    { name: "Home", href: "/" },
    { name: "About", href: "/about" },
    { name: "Testimonials", href: "/testimonials" },
    { name: "Contact", href: "/contact" },
  ]

  const services = [
    {
      title: "Nurse Placement",
      href: "/services/nurse-placement",
      description: "Foreign-trained RN placement in US healthcare facilities",
      icon: "👩‍⚕️",
    },
    {
      title: "CPR Certification",
      href: "/services/cpr-certification",
      description: "AHA certified CPR training and certification",
      icon: "❤️",
    },
    {
      title: "AED Training",
      href: "/services/aed-training",
      description: "Learn to operate AED devices and save lives",
      icon: "⚡",
    },
    {
      title: "Pathogen Training",
      href: "/services/pathogen-training",
      description: "Bloodborne and respiratory pathogen protection",
      icon: "🛡️",
    },
    {
      title: "Clinical Operations",
      href: "/services/clinical-operations",
      description: "Healthcare business operations consulting",
      icon: "🏢",
    },
  ]

  return (
    <>
      {/* Top Bar */}
      <div className="bg-gradient-to-r from-blue-900 to-blue-800 text-white py-2 px-4 hidden lg:block">
        <div className="max-w-7xl mx-auto flex justify-between items-center text-sm">
          <div className="flex items-center space-x-6">
            <div className="flex items-center space-x-2">
              <Phone className="w-4 h-4" />
              <span>+1 (317) 268-2030</span>
            </div>
            <div className="flex items-center space-x-2">
              <Mail className="w-4 h-4" />
              <span>info@kimpowellnurses.com</span>
            </div>
          </div>
          <div className="text-blue-200">🌟 Premier Nursing Consultancy - 30+ Years Experience</div>
        </div>
      </div>

      {/* Main Header */}
      <header
        className={`sticky top-0 z-50 w-full transition-all duration-300 ${
          isScrolled
            ? "bg-white/95 backdrop-blur-md shadow-lg border-b border-gray-200"
            : "bg-white border-b border-gray-100"
        }`}
      >
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex h-20 items-center justify-between">
            {/* Logo */}
            <Link href="/" className="flex items-center space-x-3 group">
              <div className="relative">
                <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-blue-700 rounded-xl flex items-center justify-center shadow-lg group-hover:shadow-xl transition-all duration-300 group-hover:scale-105">
                  <Heart className="w-7 h-7 text-white" />
                </div>
                <div className="absolute -top-1 -right-1 w-4 h-4 bg-green-500 rounded-full border-2 border-white"></div>
              </div>
              <div className="hidden sm:block">
                <div className="font-bold text-xl text-gray-900 leading-tight">Kimberly Powell</div>
                <div className="text-sm text-blue-600 font-medium -mt-1">Nurse Consultants</div>
              </div>
              <div className="sm:hidden">
                <span className="font-bold text-xl text-gray-900">KPNC</span>
              </div>
            </Link>

            {/* Desktop Navigation */}
            <div className="hidden lg:flex items-center space-x-1">
              <NavigationMenu>
                <NavigationMenuList>
                  {navigation.map((item) => (
                    <NavigationMenuItem key={item.name}>
                      <Link href={item.href} legacyBehavior passHref>
                        <NavigationMenuLink className="group inline-flex h-12 w-max items-center justify-center rounded-lg px-4 py-2 text-sm font-medium text-gray-700 transition-all hover:bg-blue-50 hover:text-blue-700 focus:bg-blue-50 focus:text-blue-700 focus:outline-none">
                          {item.name}
                        </NavigationMenuLink>
                      </Link>
                    </NavigationMenuItem>
                  ))}

                  {/* Services Dropdown */}
                  <NavigationMenuItem>
                    <NavigationMenuTrigger className="group inline-flex h-12 w-max items-center justify-center rounded-lg px-4 py-2 text-sm font-medium text-gray-700 transition-all hover:bg-blue-50 hover:text-blue-700 focus:bg-blue-50 focus:text-blue-700 focus:outline-none data-[active]:bg-blue-50 data-[state=open]:bg-blue-50">
                      Services
                    </NavigationMenuTrigger>
                    <NavigationMenuContent>
                      <div className="w-[650px] p-6">
                        <div className="mb-4">
                          <h3 className="text-lg font-semibold text-gray-900 mb-2">Our Services</h3>
                          <p className="text-sm text-gray-600">
                            Comprehensive healthcare solutions for your career advancement
                          </p>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          {services.map((service) => (
                            <Link
                              key={service.title}
                              href={service.href}
                              className="group block p-4 rounded-xl hover:bg-gradient-to-br hover:from-blue-50 hover:to-green-50 transition-all duration-200 border border-transparent hover:border-blue-100"
                            >
                              <div className="flex items-start space-x-3">
                                <div className="text-2xl">{service.icon}</div>
                                <div className="flex-1">
                                  <div className="font-semibold text-gray-900 group-hover:text-blue-700 mb-1">
                                    {service.title}
                                  </div>
                                  <p className="text-sm text-gray-600 leading-relaxed">{service.description}</p>
                                </div>
                              </div>
                            </Link>
                          ))}
                        </div>
                        <div className="mt-6 pt-4 border-t border-gray-100">
                          <Link
                            href="/services"
                            className="inline-flex items-center text-sm font-medium text-blue-600 hover:text-blue-700"
                          >
                            View All Services
                            <ChevronDown className="ml-1 h-4 w-4 rotate-[-90deg]" />
                          </Link>
                        </div>
                      </div>
                    </NavigationMenuContent>
                  </NavigationMenuItem>
                </NavigationMenuList>
              </NavigationMenu>
            </div>

            {/* CTA Button & Mobile Menu */}
            <div className="flex items-center space-x-4">
              <Button
                asChild
                className="hidden md:inline-flex bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white shadow-lg hover:shadow-xl transition-all duration-300"
              >
                <Link href="/rn-placement-form">Apply Now</Link>
              </Button>

              {/* Mobile Navigation */}
              <Sheet open={isOpen} onOpenChange={setIsOpen}>
                <SheetTrigger asChild className="lg:hidden">
                  <Button variant="ghost" size="icon" className="relative">
                    <Menu className="h-6 w-6" />
                  </Button>
                </SheetTrigger>
                <SheetContent side="right" className="w-[350px] sm:w-[400px] bg-white">
                  <div className="flex flex-col h-full">
                    {/* Mobile Header */}
                    <div className="flex items-center space-x-3 pb-6 border-b border-gray-100">
                      <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-blue-700 rounded-lg flex items-center justify-center">
                        <Heart className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <div className="font-bold text-gray-900">Kimberly Powell</div>
                        <div className="text-sm text-blue-600">Nurse Consultants</div>
                      </div>
                    </div>

                    {/* Mobile Navigation Links */}
                    <div className="flex-1 py-6 space-y-1">
                      {navigation.map((item) => (
                        <Link
                          key={item.name}
                          href={item.href}
                          className="flex items-center px-4 py-3 text-gray-700 hover:bg-blue-50 hover:text-blue-700 rounded-lg transition-colors"
                          onClick={() => setIsOpen(false)}
                        >
                          {item.name}
                        </Link>
                      ))}

                      {/* Mobile Services Section */}
                      <div className="pt-4">
                        <div className="px-4 py-2 text-sm font-semibold text-gray-900 border-b border-gray-100 mb-2">
                          Services
                        </div>
                        {services.map((service) => (
                          <Link
                            key={service.title}
                            href={service.href}
                            className="flex items-center px-4 py-3 text-gray-600 hover:bg-blue-50 hover:text-blue-700 rounded-lg transition-colors"
                            onClick={() => setIsOpen(false)}
                          >
                            <span className="mr-3 text-lg">{service.icon}</span>
                            {service.title}
                          </Link>
                        ))}
                        <Link
                          href="/services"
                          className="flex items-center px-4 py-3 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors font-medium"
                          onClick={() => setIsOpen(false)}
                        >
                          View All Services
                        </Link>
                      </div>
                    </div>

                    {/* Mobile CTA */}
                    <div className="border-t border-gray-100 pt-6">
                      <Button
                        asChild
                        className="w-full bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white"
                      >
                        <Link href="/rn-placement-form" onClick={() => setIsOpen(false)}>
                          Apply for RN Placement
                        </Link>
                      </Button>

                      {/* Mobile Contact Info */}
                      <div className="mt-4 space-y-2 text-sm text-gray-600">
                        <div className="flex items-center space-x-2">
                          <Phone className="w-4 h-4" />
                          <span>+1 (317) 268-2030</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Mail className="w-4 h-4" />
                          <span>info@kimpowellnurses.com</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </SheetContent>
              </Sheet>
            </div>
          </div>
        </div>
      </header>
    </>
  )
}
