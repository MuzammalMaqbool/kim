import Link from "next/link"
import { Heart, Phone, Mail, MapPin, Facebook, Twitter, Linkedin, Instagram } from "lucide-react"

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="space-y-4 sm:col-span-2 lg:col-span-1">
            <Link href="/" className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
                <Heart className="w-5 h-5 text-white" />
              </div>
              <span className="font-bold text-base lg:text-lg">
                Kimberly Powell
                <br />
                Nurse Consultants
              </span>
            </Link>
            <p className="text-gray-300 text-sm">
              Premier nursing consultancy specializing in nurse placement, clinical training, and healthcare business
              operations.
            </p>
            <div className="flex space-x-4">
              <Facebook className="w-5 h-5 text-gray-400 hover:text-blue-400 cursor-pointer transition-colors" />
              <Twitter className="w-5 h-5 text-gray-400 hover:text-blue-400 cursor-pointer transition-colors" />
              <Linkedin className="w-5 h-5 text-gray-400 hover:text-blue-400 cursor-pointer transition-colors" />
              <Instagram className="w-5 h-5 text-gray-400 hover:text-blue-400 cursor-pointer transition-colors" />
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-semibold text-base lg:text-lg mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/" className="text-gray-300 hover:text-white transition-colors text-sm">
                  Home
                </Link>
              </li>
              <li>
                <Link href="/about" className="text-gray-300 hover:text-white transition-colors text-sm">
                  About Us
                </Link>
              </li>
              <li>
                <Link href="/services" className="text-gray-300 hover:text-white transition-colors text-sm">
                  Services
                </Link>
              </li>
              <li>
                <Link href="/testimonials" className="text-gray-300 hover:text-white transition-colors text-sm">
                  Testimonials
                </Link>
              </li>
              <li>
                <Link href="/contact" className="text-gray-300 hover:text-white transition-colors text-sm">
                  Contact
                </Link>
              </li>
            </ul>
          </div>

          {/* Services */}
          <div>
            <h3 className="font-semibold text-base lg:text-lg mb-4">Our Services</h3>
            <ul className="space-y-2">
              <li>
                <Link
                  href="/services/nurse-placement"
                  className="text-gray-300 hover:text-white transition-colors text-sm"
                >
                  Nurse Placement
                </Link>
              </li>
              <li>
                <Link
                  href="/services/cpr-certification"
                  className="text-gray-300 hover:text-white transition-colors text-sm"
                >
                  CPR Certification
                </Link>
              </li>
              <li>
                <Link
                  href="/services/aed-training"
                  className="text-gray-300 hover:text-white transition-colors text-sm"
                >
                  AED Training
                </Link>
              </li>
              <li>
                <Link
                  href="/services/pathogen-training"
                  className="text-gray-300 hover:text-white transition-colors text-sm"
                >
                  Pathogen Training
                </Link>
              </li>
              <li>
                <Link
                  href="/services/clinical-operations"
                  className="text-gray-300 hover:text-white transition-colors text-sm"
                >
                  Clinical Operations
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="font-semibold text-base lg:text-lg mb-4">Contact Info</h3>
            <div className="space-y-3">
              <div className="flex items-center space-x-3">
                <Phone className="w-4 h-4 lg:w-5 lg:h-5 text-blue-400 flex-shrink-0" />
                <span className="text-gray-300 text-sm">+1 (317) 268-2030</span>
              </div>
              <div className="flex items-center space-x-3">
                <Mail className="w-4 h-4 lg:w-5 lg:h-5 text-blue-400 flex-shrink-0" />
                <span className="text-gray-300 text-sm break-all">info@kimpowellnurses.com</span>
              </div>
              <div className="flex items-start space-x-3">
                <MapPin className="w-4 h-4 lg:w-5 lg:h-5 text-blue-400 mt-1 flex-shrink-0" />
                <span className="text-gray-300 text-sm">
                  3250A West 86th St. #1288
                  <br />
                  Indianapolis, IN 46268
                </span>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-8 pt-8 text-center">
          <p className="text-gray-400">© 2024 Kimberly Powell Nurse Consultants. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}
