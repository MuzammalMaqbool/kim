import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Heart, Shield, Zap, Users, Award, Building } from "lucide-react"
import Link from "next/link"

export const metadata = {
  title: "Our Services | Kimberly Powell Nurse Consultants",
  description:
    "Comprehensive nursing and healthcare services including RN placement, CPR certification, AED training, pathogen training, and clinical business operations consulting.",
}

export default function ServicesPage() {
  const services = [
    {
      icon: Users,
      title: "Nurse Placement Services",
      description:
        "We specialize in placing foreign trained Registered Nurses in permanent positions within the United States healthcare system.",
      features: [
        "Comprehensive application support",
        "NCLEX-RN preparation assistance",
        "Visa and immigration guidance",
        "Job matching with top facilities",
        "Ongoing career support",
      ],
      color: "blue",
      href: "/services/nurse-placement",
    },
    {
      icon: Heart,
      title: "CPR Certification & Recertification",
      description:
        "Learn life-saving skills from American Heart Association certified CPR trainers with hands-on training and certification.",
      features: [
        "AHA certified instructors",
        "Adult, child, and infant CPR",
        "Hands-on practice sessions",
        "Certification valid for 2 years",
        "Group and individual training",
      ],
      color: "red",
      href: "/services/cpr-certification",
    },
    {
      icon: Shield,
      title: "Bloodborne & Respiratory Pathogens Training",
      description:
        "Comprehensive training on protection against bloodborne and respiratory pathogens in healthcare settings.",
      features: [
        "OSHA compliant training",
        "Infection control protocols",
        "Personal protective equipment",
        "Exposure prevention strategies",
        "Certification upon completion",
      ],
      color: "green",
      href: "/services/pathogen-training",
    },
    {
      icon: Zap,
      title: "AED Training",
      description:
        "Learn from our expert nurse team how to correctly utilize an AED and provide lifesaving care when it's most needed.",
      features: [
        "Hands-on AED operation",
        "Emergency response protocols",
        "CPR integration training",
        "Scenario-based practice",
        "Certification included",
      ],
      color: "yellow",
      href: "/services/aed-training",
    },
    {
      icon: Building,
      title: "Clinical Business Operations",
      description:
        "Our clinical experts provide business consulting services to help organizations streamline processes and maximize efficiency.",
      features: [
        "Process optimization",
        "Workflow analysis",
        "Staff efficiency improvement",
        "Cost reduction strategies",
        "Quality improvement initiatives",
      ],
      color: "purple",
      href: "/services/clinical-operations",
    },
    {
      icon: Award,
      title: "Professional Development",
      description:
        "Continuing education and professional development programs for healthcare professionals at all levels.",
      features: [
        "Continuing education units",
        "Leadership development",
        "Specialty certifications",
        "Career advancement planning",
        "Mentorship programs",
      ],
      color: "indigo",
      href: "/services/professional-development",
    },
  ]

  const getColorClasses = (color: string) => {
    const colors = {
      blue: "bg-blue-100 text-blue-600",
      red: "bg-red-100 text-red-600",
      green: "bg-green-100 text-green-600",
      yellow: "bg-yellow-100 text-yellow-600",
      purple: "bg-purple-100 text-purple-600",
      indigo: "bg-indigo-100 text-indigo-600",
    }
    return colors[color as keyof typeof colors] || colors.blue
  }

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-50 via-white to-green-50 py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-200 mb-4">Our Services</Badge>
            <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
              Comprehensive <span className="text-blue-600">Healthcare Solutions</span>
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              From nurse placement to clinical training and business operations consulting, we provide end-to-end
              healthcare solutions designed to advance careers and improve patient care.
            </p>
          </div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-20 px-4 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12">
            {services.map((service, index) => (
              <Card key={index} className="group hover:shadow-2xl transition-all duration-300 border-0 shadow-lg">
                <CardHeader className="pb-4">
                  <div
                    className={`w-16 h-16 ${getColorClasses(service.color)} rounded-full flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}
                  >
                    <service.icon className="w-8 h-8" />
                  </div>
                  <CardTitle className="text-2xl text-gray-900 mb-2">{service.title}</CardTitle>
                  <CardDescription className="text-gray-600 text-base leading-relaxed">
                    {service.description}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-3">
                    <h4 className="font-semibold text-gray-900">Key Features:</h4>
                    <ul className="space-y-2">
                      {service.features.map((feature, featureIndex) => (
                        <li key={featureIndex} className="flex items-center space-x-3">
                          <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
                          <span className="text-gray-600">{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div className="flex gap-3">
                    <Button asChild className="flex-1">
                      <Link href={service.href}>Learn More</Link>
                    </Button>
                    <Button asChild variant="outline" className="flex-1 bg-transparent">
                      <Link href="/contact">Contact Us</Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section className="py-20 px-4 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">Why Choose Our Services?</h2>
            <p className="text-xl text-gray-600">Decades of experience and proven results in healthcare excellence</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="w-20 h-20 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Award className="w-10 h-10 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">30+ Years Experience</h3>
              <p className="text-gray-600">Combined healthcare expertise across multiple specialties</p>
            </div>

            <div className="text-center">
              <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="w-10 h-10 text-green-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">500+ Nurses Placed</h3>
              <p className="text-gray-600">Successfully placed nurses in top US healthcare facilities</p>
            </div>

            <div className="text-center">
              <div className="w-20 h-20 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Heart className="w-10 h-10 text-purple-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">AHA Certified</h3>
              <p className="text-gray-600">American Heart Association certified training programs</p>
            </div>

            <div className="text-center">
              <div className="w-20 h-20 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Shield className="w-10 h-10 text-orange-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">100% Compliance</h3>
              <p className="text-gray-600">OSHA compliant training and certification programs</p>
            </div>
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-20 px-4 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">Our Process</h2>
            <p className="text-xl text-gray-600">Simple steps to get started with our services</p>
          </div>

          <div className="grid md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-600 text-white rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold">
                1
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Initial Consultation</h3>
              <p className="text-gray-600">We discuss your needs and goals to determine the best service approach</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-green-600 text-white rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold">
                2
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Customized Plan</h3>
              <p className="text-gray-600">
                We create a tailored plan based on your specific requirements and timeline
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-purple-600 text-white rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold">
                3
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Implementation</h3>
              <p className="text-gray-600">
                We execute the plan with regular updates and support throughout the process
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-orange-600 text-white rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold">
                4
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Ongoing Support</h3>
              <p className="text-gray-600">We provide continued support and follow-up to ensure your success</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 bg-blue-600">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl lg:text-4xl font-bold text-white mb-6">Ready to Get Started?</h2>
          <p className="text-xl text-blue-100 mb-8">
            Contact us today to discuss how our services can help you achieve your healthcare goals
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" variant="secondary">
              <Link href="/contact">Contact Us Today</Link>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="text-white border-white hover:bg-white hover:text-blue-600 bg-transparent"
            >
              <Link href="/rn-placement-form">Apply for RN Placement</Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}
