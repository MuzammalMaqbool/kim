import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Globe, Award, CheckCircle, ArrowRight } from "lucide-react"
import Link from "next/link"
import Image from "next/image"

export const metadata = {
  title: "Nurse Placement Services | Kimberly Powell Nurse Consultants",
  description:
    "Professional nurse placement services for foreign-trained RNs seeking permanent positions in US healthcare facilities. Expert guidance through licensing, visa, and job placement process.",
  keywords:
    "nurse placement, RN placement USA, foreign nurses, nursing jobs America, NCLEX preparation, visa assistance",
}

export default function NursePlacementPage() {
  const placementProcess = [
    {
      step: 1,
      title: "Initial Assessment",
      description: "Comprehensive evaluation of your qualifications, experience, and career goals",
      duration: "1-2 weeks",
    },
    {
      step: 2,
      title: "Documentation Review",
      description: "Review and verification of nursing credentials, licenses, and educational background",
      duration: "2-3 weeks",
    },
    {
      step: 3,
      title: "NCLEX-RN Preparation",
      description: "Comprehensive preparation and support for the NCLEX-RN examination",
      duration: "3-6 months",
    },
    {
      step: 4,
      title: "Visa Processing",
      description: "Complete assistance with visa applications and immigration documentation",
      duration: "6-12 months",
    },
    {
      step: 5,
      title: "Job Matching",
      description: "Placement with healthcare facilities that match your skills and preferences",
      duration: "2-4 weeks",
    },
    {
      step: 6,
      title: "Ongoing Support",
      description: "Continued support during transition and career development",
      duration: "Ongoing",
    },
  ]

  const benefits = [
    "Permanent positions in top US healthcare facilities",
    "Competitive salaries and comprehensive benefits",
    "Professional development opportunities",
    "Pathway to permanent residency",
    "Access to advanced medical technology",
    "Multicultural work environment",
  ]

  const requirements = [
    "Valid nursing license from your home country",
    "Minimum 2 years of clinical nursing experience",
    "English proficiency (IELTS/TOEFL scores)",
    "Clean criminal background check",
    "Medical examination and vaccinations",
    "Educational credential evaluation",
  ]

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-50 via-white to-green-50 py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-200">Premier Placement Service</Badge>
              <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 leading-tight">
                Launch Your <span className="text-blue-600">Nursing Career</span> in the United States
              </h1>
              <p className="text-xl text-gray-600 leading-relaxed">
                We specialize in placing foreign-trained Registered Nurses in permanent positions within the United
                States healthcare system. Our comprehensive support covers everything from licensing to job placement.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button asChild size="lg" className="bg-blue-600 hover:bg-blue-700">
                  <Link href="/rn-placement-form">Start Your Application</Link>
                </Button>
                <Button asChild variant="outline" size="lg">
                  <Link href="/contact">Schedule Consultation</Link>
                </Button>
              </div>
            </div>
            <div className="relative">
              <Image
                src="/placeholder.svg?height=500&width=600"
                alt="Nurses working in modern US hospital"
                width={600}
                height={500}
                className="rounded-2xl shadow-xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-20 px-4 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">Why Choose US Nursing Placement?</h2>
            <p className="text-xl text-gray-600">Discover the advantages of advancing your nursing career in America</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {benefits.map((benefit, index) => (
              <Card key={index} className="border-0 shadow-lg hover:shadow-xl transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-start space-x-3">
                    <CheckCircle className="w-6 h-6 text-green-600 mt-1 flex-shrink-0" />
                    <p className="text-gray-700 font-medium">{benefit}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-20 px-4 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">Our Placement Process</h2>
            <p className="text-xl text-gray-600">Step-by-step guidance from application to placement</p>
          </div>

          <div className="space-y-8">
            {placementProcess.map((process, index) => (
              <Card key={index} className="border-0 shadow-lg">
                <CardContent className="p-8">
                  <div className="grid md:grid-cols-4 gap-6 items-center">
                    <div className="text-center md:text-left">
                      <div className="w-16 h-16 bg-blue-600 text-white rounded-full flex items-center justify-center mx-auto md:mx-0 mb-4 text-xl font-bold">
                        {process.step}
                      </div>
                    </div>
                    <div className="md:col-span-2">
                      <h3 className="text-xl font-semibold text-gray-900 mb-2">{process.title}</h3>
                      <p className="text-gray-600">{process.description}</p>
                    </div>
                    <div className="text-center md:text-right">
                      <Badge variant="outline" className="text-sm">
                        {process.duration}
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Requirements Section */}
      <section className="py-20 px-4 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12">
            <div>
              <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-6">Eligibility Requirements</h2>
              <p className="text-lg text-gray-600 mb-8">
                To be eligible for our nurse placement program, candidates must meet the following requirements:
              </p>
              <div className="space-y-4">
                {requirements.map((requirement, index) => (
                  <div key={index} className="flex items-start space-x-3">
                    <CheckCircle className="w-6 h-6 text-blue-600 mt-1 flex-shrink-0" />
                    <p className="text-gray-700">{requirement}</p>
                  </div>
                ))}
              </div>
            </div>
            <div className="space-y-6">
              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Globe className="w-6 h-6 text-blue-600" />
                    <span>Countries We Serve</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div>• Philippines</div>
                    <div>• India</div>
                    <div>• Nigeria</div>
                    <div>• Jamaica</div>
                    <div>• South Africa</div>
                    <div>• Kenya</div>
                    <div>• Ghana</div>
                    <div>• And many more</div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Award className="w-6 h-6 text-green-600" />
                    <span>Success Statistics</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex justify-between">
                    <span>Placement Success Rate</span>
                    <span className="font-semibold text-green-600">98%</span>
                  </div>
                  <div className="flex justify-between">
                    <span>NCLEX-RN Pass Rate</span>
                    <span className="font-semibold text-blue-600">95%</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Average Placement Time</span>
                    <span className="font-semibold text-purple-600">8-12 months</span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 bg-blue-600">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl lg:text-4xl font-bold text-white mb-6">Ready to Start Your US Nursing Journey?</h2>
          <p className="text-xl text-blue-100 mb-8">
            Take the first step towards your American nursing career. Our expert team is here to guide you every step of
            the way.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" variant="secondary">
              <Link href="/rn-placement-form">
                Complete Application <ArrowRight className="w-5 h-5 ml-2" />
              </Link>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="text-white border-white hover:bg-white hover:text-blue-600 bg-transparent"
            >
              <Link href="/contact">Schedule Free Consultation</Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}
