import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Building, TrendingUp, Users, Cog, CheckCircle, Target } from "lucide-react"
import Link from "next/link"
import Image from "next/image"

export const metadata = {
  title: "Clinical Business Operations Consulting | Kimberly Powell Nurse Consultants",
  description:
    "Expert clinical business operations consulting to streamline healthcare processes, maximize efficiency, and improve patient outcomes. 30+ years of healthcare expertise.",
  keywords:
    "healthcare consulting, clinical operations, process optimization, healthcare efficiency, workflow improvement",
}

export default function ClinicalOperationsPage() {
  const services = [
    {
      title: "Process Optimization",
      icon: Cog,
      description: "Streamline clinical workflows and eliminate inefficiencies",
      benefits: [
        "Workflow analysis and redesign",
        "Bottleneck identification and resolution",
        "Standard operating procedure development",
        "Technology integration planning",
        "Quality improvement initiatives",
      ],
    },
    {
      title: "Staff Efficiency Improvement",
      icon: Users,
      description: "Maximize staff productivity and job satisfaction",
      benefits: [
        "Staffing model optimization",
        "Competency-based training programs",
        "Performance measurement systems",
        "Staff retention strategies",
        "Leadership development programs",
      ],
    },
    {
      title: "Cost Reduction Strategies",
      icon: TrendingUp,
      description: "Identify and implement cost-saving opportunities",
      benefits: [
        "Financial analysis and benchmarking",
        "Resource utilization optimization",
        "Vendor management strategies",
        "Supply chain improvements",
        "Revenue cycle optimization",
      ],
    },
    {
      title: "Quality Improvement",
      icon: Target,
      description: "Enhance patient outcomes and safety measures",
      benefits: [
        "Quality metrics development",
        "Patient safety initiatives",
        "Compliance program management",
        "Risk assessment and mitigation",
        "Accreditation preparation",
      ],
    },
  ]

  const clientTypes = [
    {
      type: "Hospitals",
      description: "Acute care facilities seeking operational excellence",
      solutions: [
        "Emergency department optimization",
        "Surgical workflow improvement",
        "Discharge planning enhancement",
      ],
    },
    {
      type: "Skilled Nursing Facilities",
      description: "Long-term care providers focused on quality and efficiency",
      solutions: ["Care plan optimization", "Staffing efficiency", "Regulatory compliance"],
    },
    {
      type: "Rehabilitation Centers",
      description: "Specialized facilities improving patient outcomes",
      solutions: ["Therapy workflow optimization", "Outcome measurement", "Interdisciplinary coordination"],
    },
    {
      type: "Outpatient Clinics",
      description: "Ambulatory care centers enhancing patient experience",
      solutions: ["Appointment scheduling optimization", "Patient flow improvement", "Provider efficiency"],
    },
  ]

  const results = [
    { metric: "30%", description: "Average efficiency improvement", color: "blue" },
    { metric: "25%", description: "Cost reduction achieved", color: "green" },
    { metric: "40%", description: "Staff satisfaction increase", color: "purple" },
    { metric: "20%", description: "Patient satisfaction improvement", color: "orange" },
  ]

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-purple-50 via-white to-blue-50 py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <Badge className="bg-purple-100 text-purple-800 hover:bg-purple-200">Healthcare Excellence</Badge>
              <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 leading-tight">
                Optimize Your <span className="text-purple-600">Clinical Operations</span>
              </h1>
              <p className="text-xl text-gray-600 leading-relaxed">
                Our team of clinical subject matter experts provide business consulting services to help healthcare
                organizations streamline processes, maximize efficiency, and improve patient outcomes.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button asChild size="lg" className="bg-purple-600 hover:bg-purple-700">
                  <Link href="/contact">Schedule Consultation</Link>
                </Button>
                <Button asChild variant="outline" size="lg">
                  <Link href="/contact">Request Assessment</Link>
                </Button>
              </div>
              <div className="flex items-center gap-8 pt-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-purple-600">30+</div>
                  <div className="text-sm text-gray-600">Years Experience</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600">100+</div>
                  <div className="text-sm text-gray-600">Projects Completed</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-600">ROI</div>
                  <div className="text-sm text-gray-600">Guaranteed</div>
                </div>
              </div>
            </div>
            <div className="relative">
              <Image
                src="/placeholder.svg?height=500&width=600"
                alt="Healthcare professionals analyzing operational data and workflows"
                width={600}
                height={500}
                className="rounded-2xl shadow-xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20 px-4 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">Our Consulting Services</h2>
            <p className="text-xl text-gray-600">Comprehensive solutions to transform your healthcare operations</p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {services.map((service, index) => (
              <Card key={index} className="border-0 shadow-lg hover:shadow-xl transition-shadow">
                <CardHeader>
                  <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mb-4">
                    <service.icon className="w-8 h-8 text-purple-600" />
                  </div>
                  <CardTitle className="text-xl">{service.title}</CardTitle>
                  <CardDescription>{service.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <h4 className="font-semibold text-gray-900 mb-3">Key Benefits:</h4>
                  <ul className="space-y-2">
                    {service.benefits.map((benefit, benefitIndex) => (
                      <li key={benefitIndex} className="flex items-start space-x-2">
                        <CheckCircle className="w-4 h-4 text-green-600 mt-1 flex-shrink-0" />
                        <span className="text-gray-600">{benefit}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Results Section */}
      <section className="py-20 px-4 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">Proven Results</h2>
            <p className="text-xl text-gray-600">Measurable improvements across all key performance indicators</p>
          </div>

          <div className="grid md:grid-cols-4 gap-8">
            {results.map((result, index) => (
              <Card key={index} className="text-center border-0 shadow-lg">
                <CardContent className="p-8">
                  <div className={`text-4xl font-bold text-${result.color}-600 mb-2`}>{result.metric}</div>
                  <div className="text-gray-600">{result.description}</div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Client Types Section */}
      <section className="py-20 px-4 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">Healthcare Organizations We Serve</h2>
            <p className="text-xl text-gray-600">Specialized solutions for different types of healthcare facilities</p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {clientTypes.map((client, index) => (
              <Card key={index} className="border-0 shadow-lg hover:shadow-xl transition-shadow">
                <CardHeader>
                  <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-3">
                    <Building className="w-6 h-6 text-blue-600" />
                  </div>
                  <CardTitle className="text-xl">{client.type}</CardTitle>
                  <CardDescription>{client.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <h4 className="font-semibold text-gray-900 mb-3">Specialized Solutions:</h4>
                  <ul className="space-y-2">
                    {client.solutions.map((solution, solutionIndex) => (
                      <li key={solutionIndex} className="flex items-start space-x-2">
                        <CheckCircle className="w-4 h-4 text-green-600 mt-1 flex-shrink-0" />
                        <span className="text-gray-600">{solution}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-20 px-4 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">Our Consulting Process</h2>
            <p className="text-xl text-gray-600">Systematic approach to operational transformation</p>
          </div>

          <div className="grid md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-purple-600 text-white rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold">
                1
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Assessment</h3>
              <p className="text-gray-600">
                Comprehensive evaluation of current operations, workflows, and performance metrics
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-blue-600 text-white rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold">
                2
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Strategy</h3>
              <p className="text-gray-600">
                Development of customized improvement strategies based on assessment findings
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-green-600 text-white rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold">
                3
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Implementation</h3>
              <p className="text-gray-600">Guided implementation of improvements with ongoing support and training</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-orange-600 text-white rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold">
                4
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Monitoring</h3>
              <p className="text-gray-600">Continuous monitoring and optimization to ensure sustained improvements</p>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonial Section */}
      <section className="py-20 px-4 bg-white">
        <div className="max-w-4xl mx-auto text-center">
          <Card className="border-0 shadow-xl">
            <CardContent className="p-12">
              <div className="text-6xl text-purple-600 mb-6">"</div>
              <p className="text-xl text-gray-700 italic mb-6">
                Excellent clinical business consulting services. They helped streamline our operations and significantly
                improved our efficiency. The ROI was evident within the first quarter of implementation. Their team's
                expertise in healthcare operations is unmatched.
              </p>
              <div className="font-semibold text-gray-900">Dr. James Rodriguez</div>
              <div className="text-gray-600">Healthcare Administrator, Texas</div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 bg-purple-600">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl lg:text-4xl font-bold text-white mb-6">Transform Your Healthcare Operations</h2>
          <p className="text-xl text-purple-100 mb-8">
            Partner with our experienced team to optimize your clinical operations, reduce costs, and improve patient
            outcomes. Let's discuss your specific challenges and goals.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" variant="secondary">
              <Link href="/contact">Schedule Free Consultation</Link>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="text-white border-white hover:bg-white hover:text-purple-600 bg-transparent"
            >
              <Link href="/contact">Request Proposal</Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}
