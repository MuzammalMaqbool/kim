import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Shield, AlertTriangle, Users, CheckCircle, FileText, Award, Microscope } from "lucide-react"
import Link from "next/link"
import Image from "next/image"

export const metadata = {
  title: "Bloodborne & Respiratory Pathogens Training | Kimberly Powell Nurse Consultants",
  description:
    "OSHA compliant bloodborne and respiratory pathogen training. Learn infection control, PPE use, and exposure prevention in healthcare settings.",
  keywords:
    "bloodborne pathogen training, respiratory pathogen training, OSHA compliance, infection control, PPE training",
}

export default function PathogenTrainingPage() {
  const trainingModules = [
    {
      title: "Bloodborne Pathogens",
      icon: Microscope,
      description: "Comprehensive training on bloodborne pathogen exposure prevention",
      topics: [
        "Hepatitis B, C, and HIV transmission",
        "Universal precautions",
        "Exposure control plans",
        "Post-exposure procedures",
        "Waste disposal protocols",
      ],
    },
    {
      title: "Respiratory Pathogens",
      icon: Shield,
      description: "Protection against airborne and droplet-transmitted infections",
      topics: [
        "COVID-19 and influenza prevention",
        "Tuberculosis precautions",
        "Respiratory hygiene protocols",
        "Isolation procedures",
        "Ventilation considerations",
      ],
    },
    {
      title: "Personal Protective Equipment",
      icon: Users,
      description: "Proper selection, use, and disposal of PPE",
      topics: [
        "PPE selection criteria",
        "Donning and doffing procedures",
        "Fit testing for respirators",
        "PPE maintenance and storage",
        "Cost-effective PPE strategies",
      ],
    },
    {
      title: "Infection Control",
      icon: AlertTriangle,
      description: "Comprehensive infection prevention and control measures",
      topics: [
        "Hand hygiene protocols",
        "Environmental cleaning",
        "Sterilization procedures",
        "Outbreak management",
        "Quality assurance programs",
      ],
    },
  ]

  const complianceFeatures = [
    "OSHA 29 CFR 1910.1030 compliant",
    "CDC guidelines integration",
    "Annual training requirements met",
    "Documentation and record keeping",
    "Customized workplace protocols",
    "Multi-language options available",
    "Online and in-person formats",
    "Continuing education credits",
  ]

  const targetAudience = [
    { role: "Healthcare Workers", description: "Nurses, doctors, technicians, and support staff" },
    { role: "Laboratory Personnel", description: "Lab technicians and researchers handling specimens" },
    { role: "Emergency Responders", description: "EMTs, paramedics, and first responders" },
    { role: "Custodial Staff", description: "Cleaning and maintenance personnel in healthcare facilities" },
    { role: "Dental Professionals", description: "Dentists, hygienists, and dental assistants" },
    { role: "Tattoo Artists", description: "Body art professionals and piercing specialists" },
  ]

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-green-50 via-white to-blue-50 py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <Badge className="bg-green-100 text-green-800 hover:bg-green-200">OSHA Compliant Training</Badge>
              <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 leading-tight">
                <span className="text-green-600">Protect</span> Against Bloodborne & Respiratory Pathogens
              </h1>
              <p className="text-xl text-gray-600 leading-relaxed">
                Learn how to protect against the most common bloodborne as well as respiratory pathogens in healthcare
                and workplace settings. Our comprehensive training ensures OSHA compliance and worker safety.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button asChild size="lg" className="bg-green-600 hover:bg-green-700">
                  <Link href="/contact">Register for Training</Link>
                </Button>
                <Button asChild variant="outline" size="lg">
                  <Link href="/contact">Request Corporate Training</Link>
                </Button>
              </div>
              <div className="flex items-center gap-8 pt-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-600">OSHA</div>
                  <div className="text-sm text-gray-600">Compliant</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600">CDC</div>
                  <div className="text-sm text-gray-600">Guidelines</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-purple-600">Annual</div>
                  <div className="text-sm text-gray-600">Required</div>
                </div>
              </div>
            </div>
            <div className="relative">
              <Image
                src="/placeholder.svg?height=500&width=600"
                alt="Healthcare worker properly using PPE and following safety protocols"
                width={600}
                height={500}
                className="rounded-2xl shadow-xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Training Modules Section */}
      <section className="py-20 px-4 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">Comprehensive Training Modules</h2>
            <p className="text-xl text-gray-600">Complete protection training covering all major pathogen categories</p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {trainingModules.map((module, index) => (
              <Card key={index} className="border-0 shadow-lg hover:shadow-xl transition-shadow">
                <CardHeader>
                  <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-4">
                    <module.icon className="w-8 h-8 text-green-600" />
                  </div>
                  <CardTitle className="text-xl">{module.title}</CardTitle>
                  <CardDescription>{module.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <h4 className="font-semibold text-gray-900 mb-3">Key Topics:</h4>
                  <ul className="space-y-2">
                    {module.topics.map((topic, topicIndex) => (
                      <li key={topicIndex} className="flex items-start space-x-2">
                        <CheckCircle className="w-4 h-4 text-green-600 mt-1 flex-shrink-0" />
                        <span className="text-gray-600">{topic}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Compliance Features Section */}
      <section className="py-20 px-4 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">Compliance & Certification</h2>
            <p className="text-xl text-gray-600">Meeting all regulatory requirements and industry standards</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {complianceFeatures.map((feature, index) => (
              <Card key={index} className="border-0 shadow-lg text-center">
                <CardContent className="p-6">
                  <CheckCircle className="w-8 h-8 text-green-600 mx-auto mb-3" />
                  <p className="text-gray-700 font-medium">{feature}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Target Audience Section */}
      <section className="py-20 px-4 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">Who Needs This Training?</h2>
            <p className="text-xl text-gray-600">Essential training for various healthcare and high-risk professions</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {targetAudience.map((audience, index) => (
              <Card key={index} className="border-0 shadow-lg hover:shadow-xl transition-shadow">
                <CardHeader>
                  <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-3">
                    <Users className="w-6 h-6 text-blue-600" />
                  </div>
                  <CardTitle className="text-lg">{audience.role}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">{audience.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Course Details Section */}
      <section className="py-20 px-4 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12">
            <div>
              <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-6">Training Details</h2>
              <div className="space-y-6">
                <Card className="border-0 shadow-lg">
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <FileText className="w-6 h-6 text-blue-600" />
                      <span>Course Information</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex justify-between">
                      <span>Duration</span>
                      <span className="font-semibold">2-4 hours</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Format</span>
                      <span className="font-semibold">Online & In-person</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Certification</span>
                      <span className="font-semibold">1 year validity</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Renewal</span>
                      <span className="font-semibold">Annual requirement</span>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-0 shadow-lg">
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Award className="w-6 h-6 text-green-600" />
                      <span>Regulatory Compliance</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex items-start space-x-3">
                      <CheckCircle className="w-5 h-5 text-green-600 mt-1" />
                      <span className="text-gray-600">OSHA 29 CFR 1910.1030 Bloodborne Pathogens Standard</span>
                    </div>
                    <div className="flex items-start space-x-3">
                      <CheckCircle className="w-5 h-5 text-green-600 mt-1" />
                      <span className="text-gray-600">CDC Infection Prevention Guidelines</span>
                    </div>
                    <div className="flex items-start space-x-3">
                      <CheckCircle className="w-5 h-5 text-green-600 mt-1" />
                      <span className="text-gray-600">Joint Commission Standards</span>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>

            <div className="space-y-6">
              <h3 className="text-2xl font-bold text-gray-900">Training Outcomes</h3>
              <p className="text-lg text-gray-600 mb-6">
                Upon completion of this training, participants will be able to:
              </p>
              <div className="space-y-4">
                {[
                  "Identify common bloodborne and respiratory pathogens",
                  "Implement proper infection control measures",
                  "Select and use appropriate personal protective equipment",
                  "Follow exposure control plans and procedures",
                  "Respond appropriately to exposure incidents",
                  "Maintain compliance with regulatory requirements",
                  "Educate others on pathogen prevention",
                  "Document training and exposure incidents properly",
                ].map((outcome, index) => (
                  <div key={index} className="flex items-start space-x-3">
                    <CheckCircle className="w-5 h-5 text-green-600 mt-1 flex-shrink-0" />
                    <span className="text-gray-700">{outcome}</span>
                  </div>
                ))}
              </div>

              <Card className="border-0 shadow-lg mt-8">
                <CardHeader>
                  <CardTitle>Workplace Benefits</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">
                    Organizations that implement comprehensive pathogen training see reduced workplace injuries,
                    improved compliance scores, and enhanced employee confidence in handling potentially infectious
                    materials.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 bg-green-600">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl lg:text-4xl font-bold text-white mb-6">Protect Your Workplace Today</h2>
          <p className="text-xl text-green-100 mb-8">
            Ensure compliance and safety with our comprehensive pathogen training programs. Protect your employees and
            meet regulatory requirements.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" variant="secondary">
              <Link href="/contact">Schedule Training</Link>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="text-white border-white hover:bg-white hover:text-green-600 bg-transparent"
            >
              <Link href="/contact">Request Quote</Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}
