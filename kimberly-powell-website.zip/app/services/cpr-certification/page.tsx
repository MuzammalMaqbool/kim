import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Heart, Users, Clock, CheckCircle, BadgeIcon as Certificate } from "lucide-react"
import Link from "next/link"
import Image from "next/image"

export const metadata = {
  title: "CPR Certification & Recertification | Kimberly Powell Nurse Consultants",
  description:
    "American Heart Association certified CPR training and certification. Learn life-saving skills from expert instructors with hands-on practice and official certification.",
  keywords: "CPR certification, AHA CPR training, CPR recertification, life saving skills, first aid training",
}

export default function CPRCertificationPage() {
  const courseTypes = [
    {
      title: "Basic Life Support (BLS)",
      description: "For healthcare professionals and trained first responders",
      duration: "4 hours",
      certification: "2 years",
      includes: ["Adult, child, and infant CPR", "AED use", "Choking relief", "Team-based resuscitation"],
    },
    {
      title: "Heartsaver CPR AED",
      description: "For anyone with little or no medical training",
      duration: "3 hours",
      certification: "2 years",
      includes: ["Adult and child CPR", "AED use", "Choking relief", "Optional infant CPR"],
    },
    {
      title: "CPR Recertification",
      description: "Renewal for previously certified individuals",
      duration: "2 hours",
      certification: "2 years",
      includes: ["Skills review", "Updated guidelines", "Hands-on practice", "New certification card"],
    },
  ]

  const benefits = [
    "American Heart Association certified instructors",
    "Hands-on practice with mannequins and AED trainers",
    "Small class sizes for personalized attention",
    "Flexible scheduling including weekends",
    "Group discounts for organizations",
    "On-site training available",
    "Digital and physical certification cards",
    "Immediate certification upon completion",
  ]

  const whoShouldAttend = [
    "Healthcare professionals",
    "Teachers and school staff",
    "Childcare providers",
    "Fitness instructors",
    "Security personnel",
    "Parents and caregivers",
    "Workplace safety teams",
    "Community volunteers",
  ]

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-red-50 via-white to-pink-50 py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <Badge className="bg-red-100 text-red-800 hover:bg-red-200">AHA Certified Training</Badge>
              <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 leading-tight">
                Learn <span className="text-red-600">Life-Saving</span> CPR Skills
              </h1>
              <p className="text-xl text-gray-600 leading-relaxed">
                Master essential CPR and AED skills with American Heart Association certified training. Our expert
                instructors provide hands-on practice to ensure you're confident in emergency situations.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button asChild size="lg" className="bg-red-600 hover:bg-red-700">
                  <Link href="/contact">Register for Training</Link>
                </Button>
                <Button asChild variant="outline" size="lg">
                  <Link href="/contact">Schedule Group Training</Link>
                </Button>
              </div>
              <div className="flex items-center gap-8 pt-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-red-600">AHA</div>
                  <div className="text-sm text-gray-600">Certified</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-600">1000+</div>
                  <div className="text-sm text-gray-600">Trained</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600">2 Years</div>
                  <div className="text-sm text-gray-600">Valid</div>
                </div>
              </div>
            </div>
            <div className="relative">
              <Image
                src="/placeholder.svg?height=500&width=600"
                alt="CPR training session with instructor and students"
                width={600}
                height={500}
                className="rounded-2xl shadow-xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Course Types Section */}
      <section className="py-20 px-4 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">CPR Certification Courses</h2>
            <p className="text-xl text-gray-600">Choose the right CPR training program for your needs</p>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            {courseTypes.map((course, index) => (
              <Card key={index} className="border-0 shadow-lg hover:shadow-xl transition-shadow">
                <CardHeader>
                  <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Heart className="w-8 h-8 text-red-600" />
                  </div>
                  <CardTitle className="text-xl text-center">{course.title}</CardTitle>
                  <CardDescription className="text-center">{course.description}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-2 gap-4 text-center">
                    <div>
                      <div className="text-lg font-semibold text-gray-900">{course.duration}</div>
                      <div className="text-sm text-gray-600">Duration</div>
                    </div>
                    <div>
                      <div className="text-lg font-semibold text-gray-900">{course.certification}</div>
                      <div className="text-sm text-gray-600">Valid For</div>
                    </div>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-3">Course Includes:</h4>
                    <ul className="space-y-2">
                      {course.includes.map((item, itemIndex) => (
                        <li key={itemIndex} className="flex items-start space-x-2">
                          <CheckCircle className="w-4 h-4 text-green-600 mt-1 flex-shrink-0" />
                          <span className="text-gray-600 text-sm">{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                  <Button asChild className="w-full">
                    <Link href="/contact">Register Now</Link>
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-20 px-4 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">Why Choose Our CPR Training?</h2>
            <p className="text-xl text-gray-600">Experience the difference of professional, certified instruction</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {benefits.map((benefit, index) => (
              <Card key={index} className="border-0 shadow-lg text-center">
                <CardContent className="p-6">
                  <CheckCircle className="w-8 h-8 text-green-600 mx-auto mb-3" />
                  <p className="text-gray-700 font-medium">{benefit}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Who Should Attend Section */}
      <section className="py-20 px-4 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12">
            <div>
              <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-6">Who Should Attend?</h2>
              <p className="text-lg text-gray-600 mb-8">
                CPR training is valuable for anyone who wants to be prepared to help in an emergency. Our courses are
                designed for various professional and personal needs.
              </p>
              <div className="grid grid-cols-2 gap-4">
                {whoShouldAttend.map((person, index) => (
                  <div key={index} className="flex items-center space-x-3">
                    <Users className="w-5 h-5 text-blue-600 flex-shrink-0" />
                    <span className="text-gray-700">{person}</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="space-y-6">
              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Certificate className="w-6 h-6 text-blue-600" />
                    <span>Certification Details</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between">
                    <span>Certification Body</span>
                    <span className="font-semibold">American Heart Association</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Validity Period</span>
                    <span className="font-semibold">2 Years</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Recognition</span>
                    <span className="font-semibold">Nationwide</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Digital Card</span>
                    <span className="font-semibold">Immediate</span>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Clock className="w-6 h-6 text-green-600" />
                    <span>Training Schedule</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div>
                    <div className="font-semibold">Weekday Classes</div>
                    <div className="text-gray-600">Monday - Friday, 9 AM - 5 PM</div>
                  </div>
                  <div>
                    <div className="font-semibold">Weekend Classes</div>
                    <div className="text-gray-600">Saturday, 9 AM - 1 PM</div>
                  </div>
                  <div>
                    <div className="font-semibold">On-Site Training</div>
                    <div className="text-gray-600">Available for groups of 6+</div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonial Section */}
      <section className="py-20 px-4 bg-gray-50">
        <div className="max-w-4xl mx-auto text-center">
          <Card className="border-0 shadow-xl">
            <CardContent className="p-12">
              <div className="text-6xl text-red-600 mb-6">"</div>
              <p className="text-xl text-gray-700 italic mb-6">
                I learned skills that enabled me to provide immediate care to one of my children who experienced a
                choking episode. The training was comprehensive and the instructors were excellent. Highly recommend
                this training to everyone!
              </p>
              <div className="font-semibold text-gray-900">Kathy D.</div>
              <div className="text-gray-600">CPR Training Graduate</div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 bg-red-600">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl lg:text-4xl font-bold text-white mb-6">Ready to Learn Life-Saving Skills?</h2>
          <p className="text-xl text-red-100 mb-8">
            Join thousands of individuals who have gained confidence and skills to help in emergency situations
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" variant="secondary">
              <Link href="/contact">Register for CPR Training</Link>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="text-white border-white hover:bg-white hover:text-red-600 bg-transparent"
            >
              <Link href="/contact">Schedule Group Training</Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}
