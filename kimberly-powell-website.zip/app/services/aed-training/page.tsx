import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Zap, Heart, Users, Clock, CheckCircle, AlertTriangle, Award } from "lucide-react"
import Link from "next/link"
import Image from "next/image"

export const metadata = {
  title: "AED Training & Certification | Kimberly Powell Nurse Consultants",
  description:
    "Professional AED (Automated External Defibrillator) training from expert nurses. Learn to save lives with proper AED operation and emergency response protocols.",
  keywords: "AED training, defibrillator training, emergency response, cardiac arrest, life saving, workplace safety",
}

export default function AEDTrainingPage() {
  const trainingComponents = [
    {
      title: "AED Operation",
      description: "Hands-on practice with actual AED devices",
      icon: Zap,
      details: ["Device setup and operation", "Electrode pad placement", "Safety protocols", "Voice prompt following"],
    },
    {
      title: "Emergency Response",
      description: "Complete emergency response protocols",
      icon: AlertTriangle,
      details: ["Scene safety assessment", "Calling for help", "Victim assessment", "Post-shock procedures"],
    },
    {
      title: "CPR Integration",
      description: "Combining AED use with CPR techniques",
      icon: Heart,
      details: ["CPR and AED coordination", "Compression techniques", "Rescue breathing", "Team-based response"],
    },
    {
      title: "Scenario Practice",
      description: "Real-world emergency simulations",
      icon: Users,
      details: ["Workplace scenarios", "Public space emergencies", "Team coordination", "Stress management"],
    },
  ]

  const benefits = [
    "Expert instruction from experienced nurses",
    "Hands-on practice with professional AED devices",
    "Small class sizes for personalized attention",
    "Certification upon successful completion",
    "Workplace compliance training available",
    "Flexible scheduling options",
    "Group discounts for organizations",
    "Refresher training available",
  ]

  const statistics = [
    { number: "350,000+", label: "Cardiac arrests annually in US", color: "red" },
    { number: "90%", label: "Occur outside hospitals", color: "blue" },
    { number: "10%", label: "Current survival rate", color: "orange" },
    { number: "70%", label: "Potential survival with AED", color: "green" },
  ]

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-yellow-50 via-white to-orange-50 py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-200">Life-Saving Technology</Badge>
              <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 leading-tight">
                Master <span className="text-yellow-600">AED Operation</span> & Save Lives
              </h1>
              <p className="text-xl text-gray-600 leading-relaxed">
                Learn from our expert nurse team how to correctly utilize an AED, listen for instructions, and give
                lifesaving care when it is most needed. Gain confidence in emergency cardiac situations.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button asChild size="lg" className="bg-yellow-600 hover:bg-yellow-700">
                  <Link href="/contact">Register for AED Training</Link>
                </Button>
                <Button asChild variant="outline" size="lg">
                  <Link href="/contact">Schedule Workplace Training</Link>
                </Button>
              </div>
            </div>
            <div className="relative">
              <Image
                src="/placeholder.svg?height=500&width=600"
                alt="AED training session with instructor demonstrating device use"
                width={600}
                height={500}
                className="rounded-2xl shadow-xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Statistics Section */}
      <section className="py-16 px-4 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Why AED Training Matters</h2>
            <p className="text-lg text-gray-600">
              Understanding the critical importance of AED availability and training
            </p>
          </div>
          <div className="grid md:grid-cols-4 gap-8">
            {statistics.map((stat, index) => (
              <Card key={index} className="text-center border-0 shadow-lg">
                <CardContent className="p-6">
                  <div className={`text-3xl font-bold text-${stat.color}-600 mb-2`}>{stat.number}</div>
                  <div className="text-gray-600">{stat.label}</div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Training Components Section */}
      <section className="py-20 px-4 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">Comprehensive AED Training</h2>
            <p className="text-xl text-gray-600">
              Complete training covering all aspects of AED use and emergency response
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {trainingComponents.map((component, index) => (
              <Card key={index} className="border-0 shadow-lg hover:shadow-xl transition-shadow">
                <CardHeader>
                  <div className="w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center mb-4">
                    <component.icon className="w-8 h-8 text-yellow-600" />
                  </div>
                  <CardTitle className="text-xl">{component.title}</CardTitle>
                  <CardDescription>{component.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {component.details.map((detail, detailIndex) => (
                      <li key={detailIndex} className="flex items-start space-x-2">
                        <CheckCircle className="w-4 h-4 text-green-600 mt-1 flex-shrink-0" />
                        <span className="text-gray-600">{detail}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-20 px-4 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">Training Benefits</h2>
            <p className="text-xl text-gray-600">Why choose our professional AED training program</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {benefits.map((benefit, index) => (
              <Card key={index} className="border-0 shadow-lg text-center">
                <CardContent className="p-6">
                  <CheckCircle className="w-8 h-8 text-green-600 mx-auto mb-3" />
                  <p className="text-gray-700 font-medium">{benefit}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Course Details Section */}
      <section className="py-20 px-4 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12">
            <div>
              <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-6">Course Details</h2>
              <div className="space-y-6">
                <Card className="border-0 shadow-lg">
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Clock className="w-6 h-6 text-blue-600" />
                      <span>Duration & Schedule</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex justify-between">
                      <span>Course Duration</span>
                      <span className="font-semibold">2-3 hours</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Class Size</span>
                      <span className="font-semibold">Maximum 12 students</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Certification</span>
                      <span className="font-semibold">2 years validity</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Prerequisites</span>
                      <span className="font-semibold">None required</span>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-0 shadow-lg">
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Award className="w-6 h-6 text-green-600" />
                      <span>Certification</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <p className="text-gray-600">
                      Upon successful completion, participants receive an official AED training certification valid for
                      2 years. This certification meets workplace safety requirements and demonstrates competency in AED
                      operation.
                    </p>
                  </CardContent>
                </Card>
              </div>
            </div>

            <div className="space-y-6">
              <h3 className="text-2xl font-bold text-gray-900">Who Should Attend?</h3>
              <div className="grid gap-4">
                {[
                  "Workplace safety coordinators",
                  "Teachers and school staff",
                  "Fitness center employees",
                  "Security personnel",
                  "Community volunteers",
                  "Healthcare support staff",
                  "Public venue employees",
                  "Anyone wanting to help in emergencies",
                ].map((person, index) => (
                  <div key={index} className="flex items-center space-x-3">
                    <Users className="w-5 h-5 text-yellow-600 flex-shrink-0" />
                    <span className="text-gray-700">{person}</span>
                  </div>
                ))}
              </div>

              <Card className="border-0 shadow-lg mt-8">
                <CardHeader>
                  <CardTitle>Workplace Compliance</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">
                    Many workplaces are required to have AED-trained personnel on-site. Our training meets OSHA
                    guidelines and helps organizations maintain compliance with safety regulations.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 bg-yellow-600">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl lg:text-4xl font-bold text-white mb-6">Be Prepared to Save a Life</h2>
          <p className="text-xl text-yellow-100 mb-8">
            Every second counts in a cardiac emergency. Get the training you need to make a difference when it matters
            most.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" variant="secondary">
              <Link href="/contact">Register for AED Training</Link>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="text-white border-white hover:bg-white hover:text-yellow-600 bg-transparent"
            >
              <Link href="/contact">Request Group Training</Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}
