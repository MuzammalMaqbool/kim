import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import Header from "@/components/header"
import Footer from "@/components/footer"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Kimberly Powell Nurse Consultants | Premier Nursing Placement & Training Services",
  description:
    "Leading nursing consultancy specializing in placing foreign-trained RNs in US healthcare facilities. Offering CPR certification, AED training, and clinical business operations consulting.",
  keywords:
    "nurse placement, RN placement, nursing jobs USA, CPR certification, AED training, healthcare consulting, foreign nurses, nursing careers",
  authors: [{ name: "Kimberly Powell Nurse Consultants" }],
  openGraph: {
    title: "Kimberly Powell Nurse Consultants | Premier Nursing Services",
    description:
      "Advance your nursing career in the United States with our professional placement and training services.",
    url: "https://kimpowellnurses.com",
    siteName: "Kimberly Powell Nurse Consultants",
    locale: "en_US",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Kimberly Powell Nurse Consultants",
    description: "Premier nursing placement and training services for healthcare professionals.",
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <Header />
        <main>{children}</main>
        <Footer />
      </body>
    </html>
  )
}
