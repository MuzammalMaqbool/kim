import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Heart, Shield, Zap, Users, Star, Phone, Mail, MapPin } from "lucide-react"
import Link from "next/link"
import Image from "next/image"

export default function HomePage() {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-blue-50 via-white to-green-50 py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-8 lg:gap-12 items-center">
            <div className="space-y-6 lg:space-y-8">
              <div className="space-y-4">
                <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-200">Premier Nursing Consultancy</Badge>
                <h1 className="text-3xl sm:text-4xl lg:text-5xl xl:text-6xl font-bold text-gray-900 leading-tight">
                  Advance Your <span className="text-blue-600">Nursing Career</span> in the United States
                </h1>
                <p className="text-lg sm:text-xl text-gray-600 leading-relaxed">
                  Are you a qualified and experienced nurse looking for an exciting opportunity to advance your career?
                  We specialize in placing foreign-trained Registered Nurses in permanent positions within US Healthcare
                  facilities.
                </p>
              </div>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button asChild size="lg" className="bg-blue-600 hover:bg-blue-700">
                  <Link href="/rn-placement-form">Complete RN Placement Form</Link>
                </Button>
                <Button asChild variant="outline" size="lg">
                  <Link href="/about">Learn More About Us</Link>
                </Button>
              </div>
              <div className="flex flex-wrap items-center gap-6 lg:gap-8 pt-4">
                <div className="text-center">
                  <div className="text-xl lg:text-2xl font-bold text-blue-600">30+</div>
                  <div className="text-xs lg:text-sm text-gray-600">Years Experience</div>
                </div>
                <div className="text-center">
                  <div className="text-xl lg:text-2xl font-bold text-green-600">500+</div>
                  <div className="text-xs lg:text-sm text-gray-600">Nurses Placed</div>
                </div>
                <div className="text-center">
                  <div className="text-xl lg:text-2xl font-bold text-purple-600">100%</div>
                  <div className="text-xs lg:text-sm text-gray-600">Success Rate</div>
                </div>
              </div>
            </div>
            <div className="relative order-first lg:order-last">
              <div className="relative z-10 bg-white rounded-2xl shadow-2xl p-4 lg:p-8">
                <Image
                  src="/images/hospital-setting-nurse-career.png"
                  alt="Professional nurse with curly hair in navy scrubs holding clipboard in modern hospital setting"
                  width={500}
                  height={400}
                  className="rounded-lg w-full h-auto"
                  priority
                />
              </div>
              <div className="absolute -top-4 -right-4 w-48 lg:w-72 h-48 lg:h-72 bg-blue-200 rounded-full opacity-20"></div>
              <div className="absolute -bottom-4 -left-4 w-32 lg:w-48 h-32 lg:h-48 bg-green-200 rounded-full opacity-20"></div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20 px-4 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">Our Professional Services</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Comprehensive healthcare consulting and training services designed to advance your career and enhance
              patient care
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="group hover:shadow-xl transition-all duration-300 border-0 shadow-lg">
              <CardHeader className="text-center pb-4">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-blue-200 transition-colors">
                  <Users className="w-8 h-8 text-blue-600" />
                </div>
                <CardTitle className="text-xl text-gray-900">Nurse Placement Firm</CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <CardDescription className="text-gray-600 mb-6">
                  We specialize in placing foreign trained Registered Nurses in permanent positions within the United
                  States.
                </CardDescription>
                <Button asChild variant="outline" className="w-full bg-transparent">
                  <Link href="/services/nurse-placement">Learn More</Link>
                </Button>
              </CardContent>
            </Card>

            <Card className="group hover:shadow-xl transition-all duration-300 border-0 shadow-lg">
              <CardHeader className="text-center pb-4">
                <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-red-200 transition-colors">
                  <Heart className="w-8 h-8 text-red-600" />
                </div>
                <CardTitle className="text-xl text-gray-900">CPR Certification</CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <CardDescription className="text-gray-600 mb-6">
                  Learn life-saving skills from American Heart Association certified CPR trainers.
                </CardDescription>
                <Button asChild variant="outline" className="w-full bg-transparent">
                  <Link href="/services/cpr-certification">Contact Us</Link>
                </Button>
              </CardContent>
            </Card>

            <Card className="group hover:shadow-xl transition-all duration-300 border-0 shadow-lg">
              <CardHeader className="text-center pb-4">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-green-200 transition-colors">
                  <Shield className="w-8 h-8 text-green-600" />
                </div>
                <CardTitle className="text-xl text-gray-900">Pathogen Training</CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <CardDescription className="text-gray-600 mb-6">
                  Learn how to protect against the most common bloodborne as well as respiratory pathogens.
                </CardDescription>
                <Button asChild variant="outline" className="w-full bg-transparent">
                  <Link href="/services/pathogen-training">Contact Us</Link>
                </Button>
              </CardContent>
            </Card>

            <Card className="group hover:shadow-xl transition-all duration-300 border-0 shadow-lg">
              <CardHeader className="text-center pb-4">
                <div className="w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-yellow-200 transition-colors">
                  <Zap className="w-8 h-8 text-yellow-600" />
                </div>
                <CardTitle className="text-xl text-gray-900">AED Training</CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <CardDescription className="text-gray-600 mb-6">
                  Learn from our nurse team how to correctly utilize an AED and give lifesaving care when needed.
                </CardDescription>
                <Button asChild variant="outline" className="w-full bg-transparent">
                  <Link href="/services/aed-training">Contact Us</Link>
                </Button>
              </CardContent>
            </Card>

            <Card className="group hover:shadow-xl transition-all duration-300 border-0 shadow-lg md:col-span-2 lg:col-span-1">
              <CardHeader className="text-center pb-4">
                <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-purple-200 transition-colors">
                  <Users className="w-8 h-8 text-purple-600" />
                </div>
                <CardTitle className="text-xl text-gray-900">Clinical Business Operations</CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <CardDescription className="text-gray-600 mb-6">
                  Our clinical experts provide business consulting to streamline processes and maximize healthcare
                  operations.
                </CardDescription>
                <Button asChild variant="outline" className="w-full bg-transparent">
                  <Link href="/services/clinical-operations">Contact Us</Link>
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 px-4 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">What Our Clients Say</h2>
            <p className="text-xl text-gray-600">Real experiences from healthcare professionals we've helped</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="border-0 shadow-lg">
              <CardContent className="p-8">
                <div className="flex items-center mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                  ))}
                </div>
                <p className="text-gray-600 mb-6 italic">
                  "I learned skills that enabled me to provide immediate care to one of my children who experienced a
                  choking episode. Highly recommend this training!"
                </p>
                <div className="font-semibold text-gray-900">Kathy D.</div>
                <div className="text-sm text-gray-500">CPR Training Graduate</div>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg">
              <CardContent className="p-8">
                <div className="flex items-center mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                  ))}
                </div>
                <p className="text-gray-600 mb-6 italic">
                  "The nurse placement program helped me achieve my dream of working in the United States. Professional
                  and supportive throughout the entire process."
                </p>
                <div className="font-semibold text-gray-900">Maria S.</div>
                <div className="text-sm text-gray-500">Registered Nurse</div>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg">
              <CardContent className="p-8">
                <div className="flex items-center mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                  ))}
                </div>
                <p className="text-gray-600 mb-6 italic">
                  "Excellent clinical business consulting services. They helped streamline our operations and
                  significantly improved our efficiency."
                </p>
                <div className="font-semibold text-gray-900">Dr. James R.</div>
                <div className="text-sm text-gray-500">Healthcare Administrator</div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 bg-blue-600">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl lg:text-4xl font-bold text-white mb-6">Ready to Advance Your Nursing Career?</h2>
          <p className="text-xl text-blue-100 mb-8">
            Join hundreds of nurses who have successfully transitioned to rewarding careers in the United States
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" variant="secondary">
              <Link href="/rn-placement-form">Get Started Today</Link>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="text-white border-white hover:bg-white hover:text-blue-600 bg-transparent"
            >
              <Link href="/contact">Contact Us</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Contact Info Section */}
      <section className="py-16 px-4 bg-gray-900">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-3 gap-8 text-center">
            <div className="flex flex-col items-center">
              <Phone className="w-8 h-8 text-blue-400 mb-4" />
              <h3 className="text-lg font-semibold text-white mb-2">Call Us</h3>
              <p className="text-gray-300">+1 (317) 268-2030</p>
            </div>
            <div className="flex flex-col items-center">
              <Mail className="w-8 h-8 text-blue-400 mb-4" />
              <h3 className="text-lg font-semibold text-white mb-2">Email Us</h3>
              <p className="text-gray-300">info@kimpowellnurses.com</p>
            </div>
            <div className="flex flex-col items-center">
              <MapPin className="w-8 h-8 text-blue-400 mb-4" />
              <h3 className="text-lg font-semibold text-white mb-2">Visit Us</h3>
              <p className="text-gray-300">
                3250A West 86th St. #1288
                <br />
                Indianapolis, IN 46268
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
