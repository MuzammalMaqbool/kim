import ContactPageClient from "./ContactPageClient"

export const metadata = {
  title: "Contact Us | Kimberly Powell Nurse Consultants",
  description:
    "Get in touch with our nursing consultancy team. We're here to help with nurse placement, training, and healthcare consulting services.",
}

export default function ContactPage() {
  return <ContactPageClient />
}
