import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Star, Quote } from "lucide-react"
import Link from "next/link"
import Image from "next/image"

export const metadata = {
  title: "Testimonials | Kimberly Powell Nurse Consultants",
  description:
    "Read success stories and testimonials from nurses and healthcare professionals who have benefited from our placement and training services.",
}

export default function TestimonialsPage() {
  const testimonials = [
    {
      name: "Kathy D.",
      role: "CPR Training Graduate",
      location: "Indianapolis, IN",
      rating: 5,
      text: "I learned skills that enabled me to provide immediate care to one of my children who experienced a choking episode. The training was comprehensive and the instructors were excellent. Highly recommend this training to everyone!",
      service: "CPR Certification",
    },
    {
      name: "Maria Santos",
      role: "Registered Nurse",
      location: "California",
      rating: 5,
      text: "The nurse placement program helped me achieve my dream of working in the United States. The team was professional and supportive throughout the entire process. They guided me through every step from licensing to job placement.",
      service: "Nurse Placement",
    },
    {
      name: "Dr. James Rodriguez",
      role: "Healthcare Administrator",
      location: "Texas",
      rating: 5,
      text: "Excellent clinical business consulting services. They helped streamline our operations and significantly improved our efficiency. The ROI was evident within the first quarter of implementation.",
      service: "Clinical Operations",
    },
    {
      name: "Sarah Johnson",
      role: "Emergency Department Nurse",
      location: "Florida",
      rating: 5,
      text: "The AED training was incredibly thorough and practical. I felt confident using the equipment after the course, and the certification has been valuable for my career advancement.",
      service: "AED Training",
    },
    {
      name: "Michael Chen",
      role: "ICU Nurse",
      location: "New York",
      rating: 5,
      text: "As a foreign-trained nurse, I was worried about the transition to working in the US. Kimberly Powell Nurse Consultants made the process smooth and stress-free. I'm now working at a top hospital in NYC.",
      service: "Nurse Placement",
    },
    {
      name: "Lisa Thompson",
      role: "Nursing Supervisor",
      location: "Ohio",
      rating: 5,
      text: "The bloodborne pathogen training was essential for our staff. The instructors were knowledgeable and made the content engaging. Our compliance scores improved significantly after the training.",
      service: "Pathogen Training",
    },
    {
      name: "Ahmed Hassan",
      role: "Registered Nurse",
      location: "Michigan",
      rating: 5,
      text: "I cannot thank the team enough for their support during my NCLEX preparation and job search. They provided resources, mock interviews, and constant encouragement. I passed on my first attempt!",
      service: "Nurse Placement",
    },
    {
      name: "Jennifer Williams",
      role: "Pediatric Nurse",
      location: "Georgia",
      rating: 5,
      text: "The CPR certification course was well-structured and hands-on. I appreciated the small class size which allowed for personalized attention. The skills I learned have been invaluable in my pediatric practice.",
      service: "CPR Certification",
    },
    {
      name: "Robert Martinez",
      role: "Hospital Administrator",
      location: "Arizona",
      rating: 5,
      text: "Their clinical business operations consulting transformed our workflow. We saw a 30% improvement in efficiency and significant cost savings. The team's expertise in healthcare operations is unmatched.",
      service: "Clinical Operations",
    },
  ]

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-50 via-white to-green-50 py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-200 mb-4">Client Success Stories</Badge>
            <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
              What Our <span className="text-blue-600">Clients Say</span>
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Real experiences from healthcare professionals who have benefited from our services. Their success stories
              inspire us to continue delivering excellence in nursing placement and training.
            </p>
          </div>

          {/* Stats */}
          <div className="grid md:grid-cols-4 gap-8 mb-16">
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-600 mb-2">500+</div>
              <div className="text-gray-600">Nurses Placed</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-green-600 mb-2">98%</div>
              <div className="text-gray-600">Success Rate</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-purple-600 mb-2">1000+</div>
              <div className="text-gray-600">Professionals Trained</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-orange-600 mb-2">4.9/5</div>
              <div className="text-gray-600">Average Rating</div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Grid */}
      <section className="py-20 px-4 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="border-0 shadow-lg hover:shadow-xl transition-shadow duration-300">
                <CardContent className="p-8">
                  <div className="flex items-center mb-4">
                    <Quote className="w-8 h-8 text-blue-600 opacity-50" />
                  </div>

                  <div className="flex items-center mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                    ))}
                  </div>

                  <p className="text-gray-600 mb-6 italic leading-relaxed">"{testimonial.text}"</p>

                  <div className="border-t pt-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-semibold text-gray-900">{testimonial.name}</div>
                        <div className="text-sm text-gray-500">{testimonial.role}</div>
                        <div className="text-sm text-gray-400">{testimonial.location}</div>
                      </div>
                      <Badge variant="outline" className="text-xs">
                        {testimonial.service}
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Video Testimonials Section */}
      <section className="py-20 px-4 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">Video Testimonials</h2>
            <p className="text-xl text-gray-600">Hear directly from our successful candidates and clients</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[1, 2, 3].map((video, index) => (
              <Card key={index} className="border-0 shadow-lg overflow-hidden">
                <div className="aspect-video bg-gray-200 relative">
                  <Image
                    src="/placeholder.svg?height=200&width=350"
                    alt={`Video testimonial ${video}`}
                    width={350}
                    height={200}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center cursor-pointer hover:bg-blue-700 transition-colors">
                      <div className="w-0 h-0 border-l-[12px] border-l-white border-t-[8px] border-t-transparent border-b-[8px] border-b-transparent ml-1"></div>
                    </div>
                  </div>
                </div>
                <CardContent className="p-6">
                  <h3 className="font-semibold text-gray-900 mb-2">Success Story {video}</h3>
                  <p className="text-gray-600 text-sm">
                    Watch how our services transformed this healthcare professional's career
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Success Metrics */}
      <section className="py-20 px-4 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">Our Track Record</h2>
            <p className="text-xl text-gray-600">Numbers that speak to our commitment to excellence</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <Card className="text-center border-0 shadow-lg">
              <CardContent className="p-8">
                <div className="text-4xl font-bold text-blue-600 mb-2">30+</div>
                <div className="text-lg font-semibold text-gray-900 mb-2">Years Experience</div>
                <div className="text-gray-600">Combined healthcare expertise</div>
              </CardContent>
            </Card>

            <Card className="text-center border-0 shadow-lg">
              <CardContent className="p-8">
                <div className="text-4xl font-bold text-green-600 mb-2">500+</div>
                <div className="text-lg font-semibold text-gray-900 mb-2">Nurses Placed</div>
                <div className="text-gray-600">Successfully placed in US facilities</div>
              </CardContent>
            </Card>

            <Card className="text-center border-0 shadow-lg">
              <CardContent className="p-8">
                <div className="text-4xl font-bold text-purple-600 mb-2">98%</div>
                <div className="text-lg font-semibold text-gray-900 mb-2">Success Rate</div>
                <div className="text-gray-600">Client satisfaction and placement success</div>
              </CardContent>
            </Card>

            <Card className="text-center border-0 shadow-lg">
              <CardContent className="p-8">
                <div className="text-4xl font-bold text-orange-600 mb-2">24/7</div>
                <div className="text-lg font-semibold text-gray-900 mb-2">Support</div>
                <div className="text-gray-600">Ongoing assistance and guidance</div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 bg-blue-600">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl lg:text-4xl font-bold text-white mb-6">Ready to Write Your Success Story?</h2>
          <p className="text-xl text-blue-100 mb-8">
            Join hundreds of healthcare professionals who have advanced their careers with our help
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" variant="secondary">
              <Link href="/rn-placement-form">Start Your Application</Link>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="text-white border-white hover:bg-white hover:text-blue-600 bg-transparent"
            >
              <Link href="/contact">Contact Us Today</Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}
